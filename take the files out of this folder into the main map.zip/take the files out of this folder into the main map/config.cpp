class CfgMods
{
	class CZRangeRoverEvoque2016
	{
	    inputs = "Projects/CZRangeRoverEvoque2016/scripts/inputs.xml";
		name = "CZRangeRoverEvoque2016";
	};
};
class CfgPatches
{
	class CZRangeRoverEvoque2016
	{
		units[]				= 
		{
			"LANEvoque2016",
			"LANEvoque2016_Blue",
			"LANEvoque2016_ChromePurple",
			"LANEvoque2016_Gold",
			"LANEvoque2016_Red",
			"LANEvoque2016_White",
			"LANEvoque2016_CoDriver",
			"LANEvoque2016_CoDriver_Blue",
			"LANEvoque2016_CoDriver_ChromePurple",
			"LANEvoque2016_CoDriver_Gold",
			"LANEvoque2016_CoDriver_Red",
			"LANEvoque2016_CoDriver_White",
			"LANEvoque2016_Driver",
			"LANEvoque2016_Driver_Blue",
			"LANEvoque2016_Driver_ChromePurple",
			"LANEvoque2016_Driver_Gold",
			"LANEvoque2016_Driver_Red",
			"LANEvoque2016_Driver_White",
			"LANEvoque2016_Hood",
			"LANEvoque2016_Hood_Blue",
			"LANEvoque2016_Hood_ChromePurple",
			"LANEvoque2016_Hood_Gold",
			"LANEvoque2016_Hood_Red",
			"LANEvoque2016_Hood_White",
			"LANEvoque2016_Trunk",
			"LANEvoque2016_Trunk_Blue",
			"LANEvoque2016_Trunk_ChromePurple",
			"LANEvoque2016_Trunk_Gold",
			"LANEvoque2016_Trunk_Red",
			"LANEvoque2016_Trunk_White",
			"LANEvoque2016_Wheel_1",
			"LANEvoque2016_Wheel_2",
			"LANEvoque2016_Wheel_3",
			"LANEvoque2016_Wheel_4",
			"LANEvoque2016_Wheel_5",
			"LANEvoque2016_Wheel_6"
		};
		weapons[]			= {};
		requiredVersion		= 0.1;
		requiredAddons[]	= 
		{			
			"DZ_Vehicles_Wheeled",
			"DZ_Vehicles_Parts",
			"DZ_Data",
			"DZ_Characters",
			"DZ_Characters_Backpacks",
			"DZ_Scripts",
			"DZ_Sounds_Effects",
			"DZ_Gear_Containers",
			"DZ_Gear_Camping"
		};
	};
};
class cfgSoundShaders
{
	class baseEngineEvoque2016_diesel_SoundShader
	{
		range = 80;
	};
	class Evoque2016_diesel_Engine_Ext_Rpm0_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Rpm0",1}};
		frequency = "0.9 * ((850 + ((rpm - 850)/(8000/5600))) max 850) / 850";
		volume = "0.9 * 1 * engineOn * 0.4 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((850+1200)/2) + 2.5*50),(((850+1200)/2) - 50)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Ext_Rpm1_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Rpm1",2}};
		frequency = "0.9 * (850 + ((rpm - 850)/(8000/5600))) / 1200";
		volume = "0.75 * 1 * (thrust factor[0.1,0.45]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 0.6 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((850+1200)/2) - 2.5*50),(((850+1200)/2) + 50)]) * ((850 + ((rpm - 850)/(8000/5600))) factor [(((1200+1700)/2) + 2.5*150),(((1200+1700)/2) - 150)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm1_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Offload_Rpm1",2}};
		frequency = "0.9 * (850 + ((rpm - 850)/(8000/5600))) / 1200";
		volume = "0.9 * 1 * (thrust factor[0.6,0.2]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 0.6 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((850+1200)/2) - 2.5*50),(((850+1200)/2) + 50)]) * ((850 + ((rpm - 850)/(8000/5600))) factor [(((1200+1700)/2) + 2.5*150),(((1200+1700)/2) - 150)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Ext_Rpm2_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Rpm2",2}};
		frequency = "0.9 * (850 + ((rpm - 850)/(8000/5600))) / 1700";
		volume = "0.75 * 1 * (thrust factor[0.1,0.45]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 0.85 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((1200+1700)/2) - 2.5*150),(((1200+1700)/2) + 150)]) * ((850 + ((rpm - 850)/(8000/5600))) factor [(((1700+2300)/2) + 2.5*150),(((1700+2300)/2) - 150)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm2_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Offload_Rpm2",2}};
		frequency = "0.9 * (850 + ((rpm - 850)/(8000/5600))) / 1700";
		volume = "0.75 * 1 * (thrust factor[0.6,0.2]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 0.85 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((1200+1700)/2) - 2.5*150),(((1200+1700)/2) + 150)]) * ((850 + ((rpm - 850)/(8000/5600))) factor [(((1700+2300)/2) + 2.5*150),(((1700+2300)/2) - 150)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Ext_Rpm3_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Rpm3",2}};
		frequency = "0.9 * (850 + ((rpm - 850)/(8000/5600))) / 2300";
		volume = "0.75 * 1 * (thrust factor[0.1,0.45]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 1 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((1700+2300)/2) - 2.5*150),(((1700+2300)/2) + 150)]) * ((850 + ((rpm - 850)/(8000/5600))) factor [(((2300+3150)/2) + 2.5*200),(((2300+3150)/2) - 200)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm3_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Offload_Rpm3",2}};
		frequency = "0.9 * (850 + ((rpm - 850)/(8000/5600))) / 2300";
		volume = "0.75 * 1 * (thrust factor[0.6,0.2]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 1 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((1700+2300)/2) - 2.5*150),(((1700+2300)/2) + 150)]) * ((850 + ((rpm - 850)/(8000/5600))) factor [(((2300+3150)/2) + 2.5*200),(((2300+3150)/2) - 200)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Ext_Rpm4_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Rpm4",2}};
		frequency = "0.9 * (850 + ((rpm - 850)/(8000/5600))) / 3150";
		volume = "0.75 * 1 * (thrust factor[0.1,0.45]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 1 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((2300+3150)/2) - 2.5*200),(((2300+3150)/2) + 200)]) * ((850 + ((rpm - 850)/(8000/5600))) factor [(((3150+4400)/2) + 2.5*200),(((3150+4400)/2) - 200)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm4_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Offload_Rpm4",2}};
		frequency = "0.9 * (850 + ((rpm - 850)/(8000/5600))) / 3150";
		volume = "0.75 * 1 * (thrust factor[0.6,0.2]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 1 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((2300+3150)/2) - 2.5*200),(((2300+3150)/2) + 200)]) * ((850 + ((rpm - 850)/(8000/5600))) factor [(((3150+4400)/2) + 2.5*200),(((3150+4400)/2) - 200)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Ext_Rpm5_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Rpm5",2}};
		frequency = "(1 * (850 + ((rpm - 850)/(8000/5600))) / 4400) min (8000/5600)";
		volume = "0.75 * 1 * (thrust factor[0.1,0.45]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 1 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((3150+4400)/2) - 2.5*200),(((3150+4400)/2) + 200)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm5_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Offload_Rpm5",2}};
		frequency = "(1 * (850 + ((rpm - 850)/(8000/5600))) / 4400) min (8000/5600)";
		volume = "0.75 * 1 * (thrust factor[0.6,0.2]) * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 1 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((3150+4400)/2) - 2.5*200),(((3150+4400)/2) + 200)]) * ((1 - 0.25*doors) max campos)";
	};
	class Evoque2016_diesel_Engine_Ext_Broken_SoundShader: baseEngineEvoque2016_diesel_SoundShader
	{
		samples[] = {{"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\sounds\Evoque2016_diesel_Engine_Ext_Broken",2}};
		frequency = 0.9;
		volume = "0.75 * 1 * (0.7 + 0.3 * (speed factor [10,60])) * engineOn * 1 * ((850 + ((rpm - 850)/(8000/5600))) factor [(((3150+4400)/2) - 2.5*200),(((3150+4400)/2) + 200)]) * ((1 - 0.25*doors) max campos) * (rpm factor[4800,6200])";
	};
};
class CfgSoundSets
{
	class baseEngine_EXT_SoundSet
	{
		sound3DProcessingType = "Vehicle_Ext_3DProcessingType";
		distanceFilter = "softVehiclesDistanceFreqAttenuationFilter";
		volumeCurve = "vehicleEngineAttenuationCurve";
		volumeFactor = 1;
		spatial = 1;
		loop = 1;
	};
	class Evoque2016_diesel_Engine_Ext_Rpm0_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Ext_Rpm0_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm1_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Offload_Ext_Rpm1_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Ext_Rpm1_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Ext_Rpm1_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Ext_Rpm2_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Ext_Rpm2_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm2_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Offload_Ext_Rpm2_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Ext_Rpm3_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Ext_Rpm3_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm3_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Offload_Ext_Rpm3_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Ext_Rpm4_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Ext_Rpm4_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm4_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Offload_Ext_Rpm4_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Ext_Rpm5_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Ext_Rpm5_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Offload_Ext_Rpm5_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Offload_Ext_Rpm5_SoundShader"};
		volumeFactor = 1;
	};
	class Evoque2016_diesel_Engine_Ext_Broken_SoundSet: baseEngine_EXT_SoundSet
	{
		soundShaders[] = {"Evoque2016_diesel_Engine_Ext_Broken_SoundShader"};
		volumeFactor = 1;
	};
};
class CfgSlots
{
	class Slot_LANEvoque2016_Wheel_1_1
	{
		name="LANEvoque2016_Wheel_1_1";
		displayName="Front Left Wheel";
		selection="wheel_1_1";
		ghostIcon="wheel";
	};
	
	class Slot_LANEvoque2016_Wheel_1_2
	{
		name="LANEvoque2016_Wheel_1_2";
		displayName="Rear Left Wheel";
		selection="wheel_1_2";
		ghostIcon="wheel";
	};
	
	class Slot_LANEvoque2016_Wheel_2_1
	{
		name="LANEvoque2016_Wheel_2_1";
		displayName="Front Right Wheel";
		selection="wheel_2_1";
		ghostIcon="wheel";
	};
	
	class Slot_LANEvoque2016_Wheel_2_2
	{
		name="LANEvoque2016_Wheel_2_2";
		displayName="Rear Right Wheel";
		selection="wheel_2_2";
		ghostIcon="wheel";
	};
	class Slot_LANEvoque2016_Driver
	{
		name="LANEvoque2016_Driver";
		displayName="Drivers Door";
		selection="doors_driver";
		ghostIcon="doorfront";
	};
	class Slot_LANEvoque2016_CoDriver
	{
		name="LANEvoque2016_CoDriver";
		displayName="Co Drivers Door";
		selection="doors_codriver";
		ghostIcon="doorfront";
	};
	class Slot_LANEvoque2016_Hood
	{
		name="LANEvoque2016_Hood";
		displayName="Golf Hood";
		selection="doors_hood";
		ghostIcon="hood";
	};
	class Slot_LANEvoque2016_Trunk
	{
		name="LANEvoque2016_Trunk";
		displayName="Golf Trunk";
		selection="doors_trunk";
		ghostIcon="trunk";
	};
	class Slot_Backpack
	{
		name="Back";
		displayName="backpack";
		selection="back";
		ghostIcon="backpack";
	};
	class slot_CanisterGasoline
	{
		name="CanisterGasoline";
		selection = "CanisterGasoline";
		ghostIcon="canistergasoline";
	};
	class Slot_Shoulder1
	{
		name = "Shoulder1";
		displayName = "Shoulder1";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder2
	{
		name = "Shoulder2";
		displayName = "Shoulder2";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder3
	{
		name = "Shoulder3";
		displayName = "Shoulder3";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder4
	{
		name = "Shoulder4";
		displayName = "Shoulder4";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder5
	{
		name = "Shoulder5";
		displayName = "Shoulder5";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder6
	{
		name = "Shoulder6";
		displayName = "Shoulder6";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder7
	{
		name = "Shoulder7";
		displayName = "Shoulder7";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder8
	{
		name = "Shoulder8";
		displayName = "Shoulder8";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder9
	{
		name = "Shoulder9";
		displayName = "Shoulder9";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder10
	{
		name = "Shoulder10";
		displayName = "Shoulder10";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder11
	{
		name = "Shoulder11";
		displayName = "Shoulder11";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder12
	{
		name = "Shoulder12";
		displayName = "Shoulder13";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder13
	{
		name = "Shoulder13";
		displayName = "Shoulder13";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder14
	{
		name = "Shoulder14";
		displayName = "Shoulder14";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder15
	{
		name = "Shoulder15";
		displayName = "Shoulder15";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder16
	{
		name = "Shoulder16";
		displayName = "Shoulder16";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder17
	{
		name = "Shoulder17";
		displayName = "Shoulder17";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder18
	{
		name = "Shoulder18";
		displayName = "Shoulder18";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder19
	{
		name = "Shoulder19";
		displayName = "Shoulder19";
		ghostIcon = "shoulderleft";
	};
	class Slot_Shoulder20
	{
		name = "Shoulder20";
		displayName = "Shoulder20";
		ghostIcon = "shoulderleft";
	};
};
class CfgWeapons
{
	class RifleCore;
	class Rifle_Base: RifleCore
	{
		inventorySlot[]=
		{
			"Shoulder1",
			"Shoulder2",
			"Shoulder3",
			"Shoulder4",
			"Shoulder5",
			"Shoulder6",
			"Shoulder7",
			"Shoulder8",
			"Shoulder9",
			"Shoulder10",
			"Shoulder11",
			"Shoulder12",
			"Shoulder13",
			"Shoulder14",
			"Shoulder15",
			"Shoulder16",
			"Shoulder17",
			"Shoulder18",
			"Shoulder19",
			"Shoulder20",
			"Shoulder21",
			"Shoulder22",
			"Shoulder23",
			"Shoulder24",
			"Shoulder25",
			"Shoulder26",
			"Shoulder27",
			"Shoulder28",
			"Shoulder29",
			"Shoulder30",
			"Melee",
			"Shoulder"
		};
	};
};
class CfgVehicles
{
	class Doors;
	class Health;
	class DamageZones;
    class Window;
	class GlobalHealth;
	class DamageSystem;
	class AnimationSources;
	class Bottle_Base;
	class CanisterGasoline: Bottle_Base
	{
		inventorySlot = "CanisterGasoline";
	};	
	class CarDoor;
	class LANEvoque2016_Driver: CarDoor
	{
		scope=2;
		displayName="Range Rover Evoque 2016 Driver Door";
		descriptionShort="Range Rover Evoque 2016 Driver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver.p3d";
		weight=15000;
		inventorySlot[]=
		{
			"LANEvoque2016_Driver"
		};
		rotationFlags=8;
		itemBehaviour=0;
		itemSize[]={8,8};
		class DamageSystem: DamageSystem
		{
			class GlobalHealth: GlobalHealth
			{
			};
			class DamageZones: DamageZones
			{
				class Window: Window
				{
					class Health: Health
					{
						healthLevels[]=
						{
							
							{
								1,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\niva_glass.rvmat"
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\niva_glass_damage.rvmat"
								}
							},
							
							{
								0.30000001,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\niva_glass_destruct.rvmat"
								}
							},
							
							{
								0,
								"hidden"
							}
						};
					};
				};
				class Doors: Doors
				{
					class Health: Health
					{
						RefTexsMats[]=
						{
							"dz\vehicles\wheeled\offroadhatchback\data\green\niva_door.rvmat"
						};
						healthLevels[]=
						{
							
							{
								1,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_door.rvmat"
								}
							},
							
							{
								0.69999999,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_door.rvmat"
								}
							},
							
							{
								0.5,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_door_damage.rvmat"
								}
							},
							
							{
								0.30000001,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_door_damage.rvmat"
								}
							},
							
							{
								0,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_door_destruct.rvmat"
								}
							}
						};
					};
				};
			};
		};
	};
	class LANEvoque2016_Driver_White : LANEvoque2016_Driver
	{
		displayName="Range Rover Evoque 2016 White Driver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_White.p3d";
	};
	class LANEvoque2016_Driver_Blue : LANEvoque2016_Driver
	{
		displayName="Range Rover Evoque 2016 Blue Driver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_Blue.p3d";
	};
	class LANEvoque2016_Driver_Red : LANEvoque2016_Driver
	{
		displayName="Range Rover Evoque 2016 Red Driver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_Red.p3d";
	};
	class LANEvoque2016_Driver_Gold : LANEvoque2016_Driver
	{
		displayName="Range Rover Evoque 2016 Gold Driver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_Gold.p3d";
	};
	class LANEvoque2016_Driver_ChromePurple : LANEvoque2016_Driver
	{
		displayName="Range Rover Evoque 2016 Chrome Purple Driver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_ChromePurple.p3d";
	};
	class LANEvoque2016_CoDriver: CarDoor
	{
		displayName="Range Rover Evoque 2016 CoDriver Door";
		descriptionShort="Range Rover Evoque 2016 CoDriver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver.p3d";
		inventorySlot[]=
		{
			"LANEvoque2016_CoDriver"
		};
		weight=15000;
		rotationFlags=8;
		itemBehaviour=0;
	};
	class LANEvoque2016_CoDriver_White : LANEvoque2016_CoDriver
	{
		displayName="Range Rover Evoque 2016 White CoDriver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_White.p3d";
	};
	class LANEvoque2016_CoDriver_Blue : LANEvoque2016_CoDriver
	{
		displayName="Range Rover Evoque 2016 Blue CoDriver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_Blue.p3d";
	};
	class LANEvoque2016_CoDriver_Red : LANEvoque2016_CoDriver
	{
		displayName="Range Rover Evoque 2016 Red CoDriver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_Red.p3d";
	};
	class LANEvoque2016_CoDriver_Gold : LANEvoque2016_CoDriver
	{
		displayName="Range Rover Evoque 2016 Gold CoDriver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_Gold.p3d";
	};
	class LANEvoque2016_CoDriver_ChromePurple : LANEvoque2016_CoDriver
	{
		displayName="Range Rover Evoque 2016 Chrome Purple CoDriver Door";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_ChromePurple.p3d";
	};
	class LANEvoque2016_Hood: CarDoor
	{
		displayName="Range Rover Evoque 2016 Hood";
		descriptionShort="Range Rover Evoque 2016 Hood";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood.p3d";
		weight=15000;
		inventorySlot[]=
		{
			"LANEvoque2016_Hood"
		};
		rotationFlags=8;
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints=500;
					RefTexsMats[]=
					{
						"dz\vehicles\wheeled\offroadhatchback\data\green\niva_hood.rvmat"
					};
					healthLevels[]=
					{
						
						{
							1,
							
							{
								"dz\vehicles\wheeled\offroadhatchback\data\green\niva_hood.rvmat"
							}
						},
						
						{
							0.69999999,
							
							{
								"dz\vehicles\wheeled\offroadhatchback\data\green\niva_hood.rvmat"
							}
						},
						
						{
							0.5,
							
							{
								"dz\vehicles\wheeled\offroadhatchback\data\green\niva_hood_damage.rvmat"
							}
						},
						
						{
							0.30000001,
							
							{
								"dz\vehicles\wheeled\offroadhatchback\data\green\niva_hood_damage.rvmat"
							}
						},
						
						{
							0,
							
							{
								"dz\vehicles\wheeled\offroadhatchback\data\green\niva_hood_destruct.rvmat"
							}
						}
					};
				};
			};
		};
		class AnimEvents
		{
			class SoundWeapon
			{
				class pickUp
				{
					soundSet="hatchbackdoors_driver_pickup_SoundSet";
					id=797;
				};
				class drop
				{
					soundset="hatchbackhood_drop_SoundSet";
					id=898;
				};
			};
		};
	};
	class LANEvoque2016_Hood_White : LANEvoque2016_Hood
	{
		displayName="Range Rover Evoque 2016 White Hood";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_White.p3d";
	};
	class LANEvoque2016_Hood_Blue : LANEvoque2016_Hood
	{
		displayName="Range Rover Evoque 2016 Blue Hood";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_Blue.p3d";
	};
	class LANEvoque2016_Hood_Red : LANEvoque2016_Hood
	{
		displayName="Range Rover Evoque 2016 Red Hood";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_Red.p3d";
	};
	class LANEvoque2016_Hood_Gold : LANEvoque2016_Hood
	{
		displayName="Range Rover Evoque 2016 Gold Hood";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_Gold.p3d";
	};
	class LANEvoque2016_Hood_ChromePurple : LANEvoque2016_Hood
	{
		displayName="Range Rover Evoque 2016  Chrome Purple Hood";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_ChromePurple.p3d";
	};
	class LANEvoque2016_Trunk: CarDoor
	{
		displayName="Range Rover Evoque 2016 Trunk";
		descriptionShort="Range Rover Evoque 2016 Trunk";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk.p3d";
		weight=15000;
		inventorySlot[]=
		{
			"LANEvoque2016_Trunk"
		};
		rotationFlags=8;
		class DamageSystem: DamageSystem
		{
			class DamageZones: DamageZones
			{
				class Window: Window
				{
					class Health: Health
					{
						healthLevels[]=
						{
							
							{
								1,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\niva_glass.rvmat"
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\niva_glass_damage.rvmat"
								}
							},
							
							{
								0.30000001,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\niva_glass_destruct.rvmat"
								}
							},
							
							{
								0,
								"hidden"
							}
						};
					};
				};
				class Doors: Doors
				{
					class Health: Health
					{
						RefTexsMats[]=
						{
							"dz\vehicles\wheeled\offroadhatchback\data\green\niva_trunk.rvmat"
						};
						healthLevels[]=
						{
							
							{
								1,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_trunk.rvmat"
								}
							},
							
							{
								0.69999999,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_trunk.rvmat"
								}
							},
							
							{
								0.5,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_trunk_damage.rvmat"
								}
							},
							
							{
								0.30000001,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_trunk_damage.rvmat"
								}
							},
							
							{
								0,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\green\niva_trunk_destruct.rvmat"
								}
							}
						};
					};
				};
			};
		};
	};
	class LANEvoque2016_Trunk_White : LANEvoque2016_Trunk
	{
		displayName="Range Rover Evoque 2016 White Trunk";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_White.p3d";
	};
	class LANEvoque2016_Trunk_Blue : LANEvoque2016_Trunk
	{
		displayName="Range Rover Evoque 2016 Blue Trunk";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_Blue.p3d";
	};
	class LANEvoque2016_Trunk_Red : LANEvoque2016_Trunk
	{
		displayName="Range Rover Evoque 2016 Red Trunk";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_Red.p3d";
	};
	class LANEvoque2016_Trunk_Gold : LANEvoque2016_Trunk
	{
		displayName="Range Rover Evoque 2016 Gold Trunk";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_Gold.p3d";
	};
	class LANEvoque2016_Trunk_ChromePurple : LANEvoque2016_Trunk
	{
		displayName="Range Rover Evoque 2016 Chrome Purple Trunk";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_ChromePurple.p3d";
	};
	class CarWheel;
	class LANEvoque2016_Wheel_1: CarWheel
	{
		scope=2;
		displayName="Range Rover Evoque 2016 Wheel Type 1";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_1.p3d";
		weight=15000;
		itemSize[]={6,6};
	    inventorySlot[]=
		{
			"LANEvoque2016_Wheel_1_1",
			"LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2"
		};
		rotationFlags=4;
		repairableWithKits[]={6};
		repairCosts[]={30};
		physLayer="item_large";
		radiusByDamage[]={0,0.350,0.30000001,0.40000001,0.99980003,0.25,0.99989998,0.2};
		radius=0.424;
		width=0.055;
		friction=2.0;
		tyreRollResistance=0.075;
		tyreTread=1;
		tyre="TYRE_DEFAULT";
	};
	class LANEvoque2016_Wheel_2: LANEvoque2016_Wheel_1
	{
		displayName="Range Rover Evoque 2016 Wheel Type 2";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_2.p3d";
	};
	class LANEvoque2016_Wheel_3: LANEvoque2016_Wheel_1
	{
		displayName="Range Rover Evoque 2016 Wheel Type 3";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_3.p3d";
	};
	class LANEvoque2016_Wheel_4: LANEvoque2016_Wheel_1
	{
		displayName="Range Rover Evoque 2016 Wheel Type 4";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_4.p3d";
	};
	class LANEvoque2016_Wheel_5: LANEvoque2016_Wheel_1
	{
		displayName="Range Rover Evoque 2016 Wheel Type 5";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_5.p3d";
	};
	class LANEvoque2016_Wheel_6: LANEvoque2016_Wheel_1
	{
		displayName="Range Rover Evoque 2016 Wheel Type 6";
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_6.p3d";
	};
    class Driver;
	class CoDriver;
	class CarScript;
	class LANEvoque2016_base : CarScript
	{
	    scope = 1;
        model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\LANEvoque2016.p3d";
		fuelCapacity = 200;
		fuelConsumption = 35;
        cameraDistance=5.8;
        cameraOffsetMS[]={0,2.3,0};
	  	attachments[]=
		{
			"CarBattery",
			"Reflector_1_1",
			"Reflector_2_1",
			"CarRadiator",
			"SparkPlug",
			"LANEvoque2016_CoDriver",
			"LANEvoque2016_Driver",
			"LANEvoque2016_Hood",
			"LANEvoque2016_Trunk",
			"LANEvoque2016_Wheel_1_1",
		    "LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2",
            "Shoulder1",
			"Shoulder2",
			"Shoulder3",
			"Shoulder4",
			"CanisterGasoline",
			"Back"
		};
		class Crew
		{
			class Driver
			{
				actionSel="seat_driver";
				proxyPos="crewDriver";
				getInPos="pos_driver";
				getInDir="pos_driver_dir";
				isDriver=1;
			};
			class CoDriver
			{
				actionSel="seat_codriver";
				proxyPos="crewCoDriver";
				getInPos="pos_codriver";
				getInDir="pos_codriver_dir";
			};
			class Cargo1
			{
				actionSel="seat_cargo1";
				proxyPos="crewCargo1";
				getInPos="pos_cargo1";
				getInDir="pos_cargo1_dir";
			};
			class Cargo2
			{
				actionSel="seat_cargo2";
				proxyPos="crewCargo2";
				getInPos="pos_cargo2";
				getInDir="pos_cargo2_dir";
			};
		};
		class GUIInventoryAttachmentsProps
		{
			class Engine
			{
				name="V8.0 Engine Turbo";
				description="";
				icon="cat_vehicle_engine";
				attachmentSlots[]=
				{
					"CarBattery",
					"CarRadiator",
					"Reflector_1_1",
			        "Reflector_2_1",
					"SparkPlug"
				};
			};
			class Body
			{
				name="Range Rover Evoque 2016 Body";
				description="";
				icon="cat_vehicle_body";
				attachmentSlots[]=
				{
					"LANEvoque2016_Hood",
					"LANEvoque2016_Driver",
					"LANEvoque2016_CoDriver",
					"LANEvoque2016_Trunk"
				};
			};
			class Chassis
			{
				name="Range Rover Evoque 2016 Chassis";
				description="";
				icon="cat_vehicle_chassis";
				attachmentSlots[]=
				{
					"LANEvoque2016_Wheel_1_1",
					"LANEvoque2016_Wheel_1_2",
					"LANEvoque2016_Wheel_2_1",
					"LANEvoque2016_Wheel_2_2"
				};
			};
			class Attachments
			{
				name="Range Rover Evoque 2016 Attachments";
				description="";
				icon="Shoulder";
				attachmentSlots[]=
				{
					"Shoulder1",
			        "Shoulder2",
			        "Shoulder3",
			        "Shoulder4",
					"CanisterGasoline",
			        "Back"
				};
			};
		};
		class Cargo
		{
			itemsCargoSize[]={10,100};
			allowOwnedCargoManipulation=1;
			openable=0;
		};
		class AnimationSources : AnimationSources
		{
			class DoorsDriver
			{
				source="user";
				initPhase=0;
				animPeriod=0.5;
			};
			class DoorsCoDriver
			{
				source="user";
				initPhase=0;
				animPeriod=0.5;
			};
			class DoorsHood
			{
				source="user";
				initPhase=0;
				animPeriod=0.5;
			};
			class DoorsTrunk : DoorsHood
			{
			};
			class RoofWindow
			{
				source="user";
				initPhase=0;
				animPeriod=0.5;
			};
			class SeatDriver
			{
				source="user";
				initPhase=0;
				animPeriod=1;
			};
			class SeatCoDriver
			{
				source="user";
				initPhase=0;
				animPeriod=1;
			};
			class damper_1_1
			{
				source="user";
				initPhase=0.48570001;
				animPeriod=1;
			};
			class damper_2_1: damper_1_1
			{
			};
			class damper_1_2
			{
				source="user";
				initPhase=0.40020001;
				animPeriod=1;
			};
			class damper_2_2: damper_1_2
			{
			};
		};	
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints=25000;
					healthLevels[]=
					{
						
						{
							1,
							{}
						},
						
						{
							0.69999999,
							{}
						},
						
						{
							0.5,
							{}
						},
						
						{
							0.30000001,
							{}
						},
						
						{
							0,
							{}
						}
					};
				};
			};
			class DamageZones
			{
				class Chassis
				{
					class Health
					{
						hitpoints=1000;
						transferToGlobalCoef=0;
					};
					componentNames[]=
					{
						"dmgZone_chassis"
					};
					fatalInjuryCoef=-1;
					inventorySlots[]={};
				};
				class Front
				{
					class Health
					{
						hitpoints=1000;
						transferToGlobalCoef=0;
						healthLevels[]=
						{
							
							{
								1,
								
								{
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
								}
							},
							
							{
								0.30000001,
								{}
							},
							
							{
								0,
								
								{
								}
							}
						};
					};
					transferToZonesNames[]=
					{
						"Radiator",
						"Engine",
						"Reflector_1_1",
						"Reflector_2_1",
						"WindowFront"
					};
					transferToZonesThreshold[]={0.5,0.80000001,0.80000001,0.5,1,1,0.1};
					transferToZonesCoefs[]={0.80000001,0.60000002,0.60000002,0.60000002,0.050000001,0.050000001,0.69999999};
					memoryPoints[]=
					{
						"dmgZone_front"
					};
					componentNames[]=
					{
					};
					fatalInjuryCoef=-1;
					inventorySlots[]=
					{
						"LANEvoque2016_Hood"
					};
				};
				class Radiator
				{
					class Health
					{
						hitpoints=100000;
						transferToGlobalCoef=0;
					};
					memoryPoints[]={};
					componentNames[]={};
					fatalInjuryCoef=-1;
					inventorySlots[]=
					{
					};
				};
				class DoorsDriver
				{
					class Health
					{
						hitpoints=1000;
						transferToGlobalCoef=0;
					};
					memoryPoints[]=
					{
						"dmgZone_doors"
					};
					componentNames[]={};
					fatalInjuryCoef=-1;
					inventorySlots[]=
					{
						"LANEvoque2016_Driver"
					};
				};
				class DoorsCoDriver
				{
					class Health
					{
						hitpoints=1000;
						transferToGlobalCoef=0;
					};
					memoryPoints[]=
					{
						"dmgZone_doors"
					};
					componentNames[]={};
					fatalInjuryCoef=-1;
					inventorySlots[]=
					{
						"LANEvoque2016_CoDriver"
					};
				};
				class Back
				{
					class Health
					{
						hitpoints=1500;
						transferToGlobalCoef=0;
						healthLevels[]=
						{
							
							{
								1,
								
								{
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
								}
							},
							
							{
								0.30000001,
								{}
							},
							
							{
								0,
								
								{
								}
							}
						};
					};
					transferToZonesNames[]=
					{
						"WindowLR",
						"WindowRR"
					};
					transferToZonesCoefs[]={0.30000001,0.30000001,0.2,0.2};
					memoryPoints[]=
					{
						"dmgZone_back"
					};
					componentNames[]=
					{
						"dmgZone_back"
					};
					fatalInjuryCoef=-1;
					inventorySlots[]=
					{
						"LANEvoque2016_Trunk"
					};
				};
				class Roof
				{
					class Health
					{
						hitpoints=1000;
						transferToGlobalCoef=0;
						healthLevels[]=
						{
							
							{
								1,
								
								{
									
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
								}
							},
							
							{
								0.30000001,
								{}
							},
							
							{
								0,
								
								{
								}
							}
						};
					};
					memoryPoints[]=
					{
						"dmgZone_roof"
					};
					componentNames[]=
					{
						"dmgZone_roof"
					};
					fatalInjuryCoef=-1;
					inventorySlots[]={};
				};
				class WindowFront
				{
					class Health
					{
						hitpoints=500;
						transferToGlobalCoef=0;
						healthLevels[]=
						{
							
							{
								1,
								
								{
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
									"dz\vehicles\wheeled\data\glass_i_damage.rvmat"
								}
							},
							
							{
								0.30000001,
								{}
							},
							
							{
								0,
								{}
							}
						};
					};
					memoryPoints[]=
					{
						"dmgZone_windowFront"
					};
					componentNames[]=
					{
						"dmgZone_windowFront"
					};
					fatalInjuryCoef=-1;
					inventorySlots[]={};
				};
				class WindowLR
				{
					class Health
					{
						hitpoints=500;
						transferToGlobalCoef=0;
						healthLevels[]=
						{
							
							{
								1,
								
								{
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
									"dz\vehicles\wheeled\data\auta_skla_damage.rvmat"
								}
							},
							
							{
								0.30000001,
								{}
							},
							
							{
								0,
								
								{
									""
								}
							}
						};
					};
					memoryPoints[]=
					{
						"dmgZone_windowLeft"
					};
					componentNames[]=
					{
						"dmgZone_windowLeft"
					};
					fatalInjuryCoef=-1;
					inventorySlots[]={};
				};
				class WindowRR: WindowLR
				{
					memoryPoints[]=
					{
						"dmgZone_windowRight"
					};
					componentNames[]=
					{
						"dmgZone_windowRight"
					};
				};
				class Engine
				{
					class Health
					{
						hitpoints=1000;
						transferToGlobalCoef=0;
						healthLevels[]=
						{
							
							{
								1,
								
								{
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
								}
							},
							
							{
								0.30000001,
								{}
							},
							
							{
								0,
								
								{
								}
							}
						};
					};
					memoryPoints[]=
					{
						"dmgZone_engine"
					};
					componentNames[]=
					{
						"dmgZone_engine"
					};
					fatalInjuryCoef=0.001;
					inventorySlots[]=
					{
					};
				};
				class FuelTank
				{
					class Health
					{
						hitpoints=600;
						transferToGlobalCoef=0;
						healthLevels[]=
						{
							
							{
								1,
								{}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								{}
							},
							
							{
								0.30000001,
								{}
							},
							
							{
								0,
								{}
							}
						};
					};
					componentNames[]=
					{
						"dmgZone_fuelTank"
					};
					fatalInjuryCoef=-1;
					inventorySlots[]={};
				};
				class Reflector_1_1
				{
					class Health
					{
						hitpoints=100;
						transferToGlobalCoef=0;
						healthLevels[]=
						{
							
							{
								1,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\headlights_glass.rvmat"
								}
							},
							
							{
								0.69999999,
								{}
							},
							
							{
								0.5,
								
								{
									"dz\vehicles\wheeled\offroadhatchback\data\glass_i_damage.rvmat"
								}
							},
							
							{
								0.30000001,
								{}
							},
							
							{
								0,
								
								{
									"dz\vehicles\wheeled\data\glass_i_destruct.rvmat"
								}
							}
						};
					};
					memoryPoints[]=
					{
						"dmgZone_lights_1_1"
					};
					componentNames[]=
					{
					};
					fatalInjuryCoef=-1;
					inventorySlots[]=
					{
						"Reflector_1_1"
					};
				};
				class Reflector_2_1: Reflector_1_1
				{
					memoryPoints[]=
					{
						"dmgZone_lights_2_1"
					};
					componentNames[]=
					{
					};
					inventorySlots[]=
					{
						"Reflector_2_1"
					};
				};
			};
		};	
		class ObstacleGenerator
		{
			carve=1;
			timeToStationary=5;
			moveThreshold=0.5;
			class Shapes
			{
				class Cylindric
				{
					class Cyl1
					{
						radius = 1;
						height = 1.5;
						center[] = {0,0,0.7};
					};
					class Cyl3
					{
						radius = 1;
						height = 1.5;
						center[] = {0,0,-0.7};
					};
				};
			};
		};
		class SimulationModule
		{
			
			drive="DRIVE_AWD";
			airDragCoefficient=0.80;
			braking[]={0,0.3,1,0.80000001,2.5,0.89999998,3,1};
			class Steering
			{
				increaseSpeed[]={0,40,60,30,100,15};
				decreaseSpeed[]={0,90,60,45,100,20};
				centeringSpeed[]={0,0,15,27,60,45,100,63};
			};
			class Throttle
			{
				reactionTime = 1;
				defaultThrust = 0.95000005;
				gentleThrust = 0.7;
				turboCoef = 2.5;
				gentleCoef = 0.75;
			};
			class Engine
			{
				inertia=0.27000001;
				torqueMax=300;
				torqueRpm=4700;
				powerMax=165;
				powerRpm=6200;
				rpmIdle=1300;
				rpmMin=1450;
				rpmClutch=1550;
				rpmRedline=6500;
				rpmMax=7800;
			};
			class Gearbox
			{
				reverse=3.526;
				ratios[]={4.1,3.0,2.3,1.6,1};
				timeToUncoupleClutch=0.25;
				timeToCoupleClutch=0.34999999;
				maxClutchTorque=300;
			};
			class Axles
			{
				class Front
				{
					
					maxSteeringAngle=30;
					finalRatio=4.0999999;
					brakeBias=0.60000002;
					brakeForce=3800;
					wheelHubMass=5;
					wheelHubRadius=0.15000001;
					class Suspension
					{
						swayBar=1600;
						stiffness=36500;
						compression=2100;
						damping=7500;
						travelMaxUp = 0.13;
						travelMaxDown = 0.1125;
					};
					class Wheels
					{
						class Left
						{
							
							animTurn="turnfrontleft";
							animRotation="wheelfrontleft";
							wheelHub="wheel_1_1_damper_land";
							animDamper="damper_1_1";
							inventorySlot="LANEvoque2016_Wheel_1_1";
						};
						class Right
						{
							
							animTurn="turnfrontright";
							animRotation="wheelfrontright";
							wheelHub="wheel_2_1_damper_land";
							animDamper="damper_2_1";
							inventorySlot="LANEvoque2016_Wheel_2_1";
						};
					};
				};
				class Rear
				{
					maxSteeringAngle=0;
					finalRatio=4.0999999;
					brakeBias=0.40000001;
					brakeForce=4000;
					wheelHubMass=5;
					wheelHubRadius=0.15000001;
					class Suspension
					{
					    swayBar=1500;
						stiffness=36600;
						compression=2200;
						damping=7500;
						travelMaxUp = 0.13;
						travelMaxDown = 0.115;
					};
					class Wheels
					{
						class Left
						{
							
							animTurn="turnbackleft";
							animRotation="wheelbackleft";
							wheelHub="wheel_1_2_damper_land";		
							animDamper="damper_1_2";
							inventorySlot="LANEvoque2016_Wheel_1_2";
						};
						class Right
						{
						
							animTurn="turnbacktright";
							animRotation="wheelbackright";
							wheelHub="wheel_2_2_damper_land";
							animDamper="damper_2_2";
							inventorySlot="LANEvoque2016_Wheel_2_2";
							
						
						};
					};
				};
			};
		};
	    engineVitalParts[]=
		{
			"SparkPlug",
			"CarBattery"
		};
	};
	class LANEvoque2016 : LANEvoque2016_base
	{
	    scope = 2;
        displayname = "Range Rover Evoque 2016 (Black)";
        model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\LANEvoque2016.p3d";	    
	  	attachments[]=
		{
			"CarBattery",
			"Reflector_1_1",
			"Reflector_2_1",
			"CarRadiator",
			"SparkPlug",
			"LANEvoque2016_CoDriver",
			"LANEvoque2016_Driver",
			"LANEvoque2016_Hood",
			"LANEvoque2016_Trunk",
			"LANEvoque2016_Wheel_1_1",
		    "LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2",
            "Shoulder1",
			"Shoulder2",
			"Shoulder3",
			"Shoulder4",
			"CanisterGasoline",
			"Back"
		};
		frontReflectorMatOn = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_lights_e.rvmat";
		frontReflectorMatOff = "dz\data\data\default.rvmat";
		brakeReflectorMatOn = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_brakelight.rvmat";
		brakeReflectorMatOff = "dz\data\data\default.rvmat";
		ReverseReflectorMatOn = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_reverse.rvmat";
		ReverseReflectorMatOff = "dz\data\data\default.rvmat";
		TailReflectorMatOn = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_rearlight.rvmat";
		TailReflectorMatOff = "dz\data\data\default.rvmat";
		dashboardMatOn = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\lanevoque2016_dashboardlights.rvmat";
		dashboardMatOff = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\lanevoque2016_dashboardlight_off.rvmat";
		hiddenSelections[] = 
		{
			"light_1_1",
			"light_2_1",
			"light_brake_1_2",
			"light_brake_2_2",
			"light_reverse_1_2",
			"light_reverse_2_2",
			"light_1_2",
			"light_2_2",
			"light_dashboard"
		};
		hiddenSelectionsTextures[] = 
		{
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Light_co.paa",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Light_co.paa",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Light_co.paa",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Light_co.paa",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Light_co.paa",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Light_co.paa",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Light_co.paa",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Light_co.paa",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\Dashboard.paa"
		};
		hiddenSelectionsMaterials[] = 
		{
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_lights_e.rvmat",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_lights_e.rvmat",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_brakelight.rvmat",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_brakelight.rvmat",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_reverse.rvmat",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_reverse.rvmat",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_rearlight.rvmat",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\car_rearlight.rvmat",
			"Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\data\lanevoque2016_dashboardlights.rvmat"
		};
		class Sounds
		{
			thrust = 0.6;
			thrustTurbo = 1;
			thrustGentle = 0.3;
			thrustSmoothCoef = 0.1;
			camposSmoothCoef = 0.03;
			soundSetsFilter[]=
			{
				"Evoque2016_diesel_Engine_Offload_Ext_Rpm1_SoundSet",
				"Evoque2016_diesel_Engine_Offload_Ext_Rpm2_SoundSet",
				"Evoque2016_diesel_Engine_Offload_Ext_Rpm3_SoundSet",
				"Evoque2016_diesel_Engine_Offload_Ext_Rpm4_SoundSet",
				"Evoque2016_diesel_Engine_Offload_Ext_Rpm5_SoundSet",
				"Evoque2016_diesel_Engine_Ext_Rpm0_SoundSet",
				"Evoque2016_diesel_Engine_Ext_Rpm1_SoundSet",
				"Evoque2016_diesel_Engine_Ext_Rpm2_SoundSet",
				"Evoque2016_diesel_Engine_Ext_Rpm3_SoundSet",
				"Evoque2016_diesel_Engine_Ext_Rpm4_SoundSet",
				"Evoque2016_diesel_Engine_Ext_Rpm5_SoundSet",
				"Evoque2016_diesel_Engine_Ext_Broken",
				"offroad_Tires_rock_slow_Ext_SoundSet",
				"offroad_Tires_rock_fast_Ext_SoundSet",
				"offroad_Tires_grass_slow_Ext_SoundSet",
				"offroad_Tires_grass_fast_Ext_SoundSet",
				"offroad_Tires_gravel_slow_Ext_SoundSet",
				"offroad_Tires_gravel_fast_Ext_SoundSet",
				"offroad_Tires_gravel_dust_fast_Ext_SoundSet",
				"offroad_Tires_asphalt_slow_Ext_SoundSet",
				"offroad_Tires_asphalt_fast_Ext_SoundSet",
				"offroad_Tires_water_slow_Ext_SoundSet",
				"offroad_Tires_water_fast_Ext_SoundSet",
				"Offroad_skid_dirt_SoundSet",
				"offroad_dirt_turn_SoundSet",
				"offroad_Rain_Ext_SoundSet",
				"offroad_damper_left_SoundSet",
				"offroad_damper_right_SoundSet"
			};
			soundSetsInt[]=
			{
				"Offroad_Tires_Asphalt_Fast_General_Int_SoundSet",
				"Offroad_Wind_SoundSet"
			};
		};
	};
	class LANEvoque2016_White : LANEvoque2016
	{
        displayname = "Range Rover Evoque 2016 (White)";
        model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\LANEvoque2016_White.p3d";	
	};
	class LANEvoque2016_Blue : LANEvoque2016
	{
        displayname = "Range Rover Evoque 2016 (Blue)";
        model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\LANEvoque2016_Blue.p3d";	
	};
	class LANEvoque2016_Red : LANEvoque2016
	{
        displayname = "Range Rover Evoque 2016 (Red)";
        model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\LANEvoque2016_Red.p3d";	
	};
	class LANEvoque2016_Gold : LANEvoque2016
	{
        displayname = "Range Rover Evoque 2016 (Gold)";
        model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\LANEvoque2016_Gold.p3d";	
	};
	class LANEvoque2016_ChromePurple : LANEvoque2016
	{
        displayname = "Range Rover Evoque 2016 (Chrome Purple)";
        model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\LANEvoque2016_ChromePurple.p3d";	
	};
};
class CfgNonAIVehicles
{
	class ProxyAttachment;
	class ProxyVehiclePart: ProxyAttachment
	{
		scope=2;
		simulation="ProxyInventory";
		autocenter=0;
		animated=0;
		shadow=1;
		reversed=0;
	};
	class ProxyLANEvoque2016_Driver: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver.p3d";
		inventorySlot="LANEvoque2016_Driver";
	};
	class ProxyLANEvoque2016_Driver_White: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_White.p3d";
		inventorySlot="LANEvoque2016_Driver";
	};
	class ProxyLANEvoque2016_Driver_Blue: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_Blue.p3d";
		inventorySlot="LANEvoque2016_Driver";
	};
	class ProxyLANEvoque2016_Driver_Red: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_Red.p3d";
		inventorySlot="LANEvoque2016_Driver";
	};
	class ProxyLANEvoque2016_Driver_Gold: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_Gold.p3d";
		inventorySlot="LANEvoque2016_Driver";
	};
	class ProxyLANEvoque2016_Driver_ChromePurple: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Driver_ChromePurple.p3d";
		inventorySlot="LANEvoque2016_Driver";
	};
	class ProxyLANEvoque2016_CoDriver: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver.p3d";
		inventorySlot="LANEvoque2016_CoDriver";
	};
	class ProxyLANEvoque2016_CoDriver_White: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_White.p3d";
		inventorySlot="LANEvoque2016_CoDriver";
	};
	class ProxyLANEvoque2016_CoDriver_Blue: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_Blue.p3d";
		inventorySlot="LANEvoque2016_CoDriver";
	};
	class ProxyLANEvoque2016_CoDriver_Red: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_Red.p3d";
		inventorySlot="LANEvoque2016_CoDriver";
	};
	class ProxyLANEvoque2016_CoDriver_Gold: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_Gold.p3d";
		inventorySlot="LANEvoque2016_CoDriver";
	};
	class ProxyLANEvoque2016_CoDriver_ChromePurple: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_CoDriver_ChromePurple.p3d";
		inventorySlot="LANEvoque2016_CoDriver";
	};
	class ProxyLANEvoque2016_Hood: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood.p3d";
		inventorySlot="LANEvoque2016_Hood";
	};
	class ProxyLANEvoque2016_Hood_White: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_White.p3d";
		inventorySlot="LANEvoque2016_Hood";
	};
	class ProxyLANEvoque2016_Hood_Blue: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_Blue.p3d";
		inventorySlot="LANEvoque2016_Hood";
	};
	class ProxyLANEvoque2016_Hood_Red: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_Red.p3d";
		inventorySlot="LANEvoque2016_Hood";
	};
	class ProxyLANEvoque2016_Hood_Gold: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_Gold.p3d";
		inventorySlot="LANEvoque2016_Hood";
	};
	class ProxyLANEvoque2016_Hood_ChromePurple: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Hood_ChromePurple.p3d";
		inventorySlot="LANEvoque2016_Hood";
	};
	class ProxyLANEvoque2016_Trunk: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk.p3d";
		inventorySlot="LANEvoque2016_Trunk";
	};
	class ProxyLANEvoque2016_Trunk_White: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_White.p3d";
		inventorySlot="LANEvoque2016_Trunk";
	};
	class ProxyLANEvoque2016_Trunk_Blue: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_Blue.p3d";
		inventorySlot="LANEvoque2016_Trunk";
	};
	class ProxyLANEvoque2016_Trunk_Red: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_Red.p3d";
		inventorySlot="LANEvoque2016_Trunk";
	};
	class ProxyLANEvoque2016_Trunk_Gold: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_Gold.p3d";
		inventorySlot="LANEvoque2016_Trunk";
	};
	class ProxyLANEvoque2016_Trunk_ChromePurple: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Trunk_ChromePurple.p3d";
		inventorySlot="LANEvoque2016_Trunk";
	};
	class ProxyBackpack: ProxyVehiclePart
	{
		model = "DZ\characters\proxies\backpack_dz.p3d";
		inventorySlot = "Back";
	};
	class ProxyCanisterGasoline: ProxyVehiclePart
	{
		model="DZ\vehicles\parts\jerrycan.p3d";
		inventorySlot="CanisterGasoline";
	};
	class Proxyevo_shoulder1: ProxyAttachment
	{
		scope=2;
		inventorySlot[] = { "Shoulder1" };
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder1.p3d";
	};
	class Proxyevo_shoulder2: ProxyAttachment
	{
		scope=2;
		inventorySlot[] = { "Shoulder2" };
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder2.p3d";
	};
	class Proxyevo_shoulder3: ProxyAttachment
	{
		scope=2;
		inventorySlot[] = { "Shoulder3" };
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder3.p3d";
	};
	class Proxyevo_shoulder4: ProxyAttachment
	{
		scope=2;
		inventorySlot[] = { "Shoulder4" };
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder4.p3d";
	};
	class Proxyevo_shoulder5: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder5"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder5.p3d";
	};
	class Proxyevo_shoulder6: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder6"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder6.p3d";
	};
	class Proxyevo_shoulder7: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder7"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder7.p3d";
	};
	class Proxyevo_shoulder8: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder8"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder8.p3d";
	};
	class Proxyevo_shoulder9: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder9"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder9.p3d";
	};
	class Proxyevo_shoulder10: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder10"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder10.p3d";
	};
	class Proxyevo_shoulder11: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder11"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder11.p3d";
	};
	class Proxyevo_shoulder12: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder12"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder12.p3d";
	};
	class Proxyevo_shoulder13: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder13"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder13.p3d";
	};
	class Proxyevo_shoulder14: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder14"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder14.p3d";
	};
	class Proxyevo_shoulder15: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder15"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder15.p3d";
	};
	class Proxyevo_shoulder16: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder16"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder16.p3d";
	};
	class Proxyevo_shoulder17: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder17"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder17.p3d";
	};
	class Proxyevo_shoulder18: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder18"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder18.p3d";
	};
	class Proxyevo_shoulder19: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder19"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder19.p3d";
	};
	class Proxyevo_shoulder20: ProxyAttachment
	{
		scope = 2;
		inventorySlot[] = {"Shoulder20"};
		model = "Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\gslot\evo_shoulder20.p3d";
	};
	class ProxyLANEvoque2016_Wheel_1: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_1.p3d";
		inventorySlot[]=
		{
			"LANEvoque2016_Wheel_1_1",
			"LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2"
		};
	};
	class ProxyLANEvoque2016_Wheel_2: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_2.p3d";
		inventorySlot[]=
		{
			"LANEvoque2016_Wheel_1_1",
			"LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2"
		};
	};
	class ProxyLANEvoque2016_Wheel_3: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_3.p3d";
		inventorySlot[]=
		{
			"LANEvoque2016_Wheel_1_1",
			"LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2"
		};
	};
	class ProxyLANEvoque2016_Wheel_4: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_4.p3d";
		inventorySlot[]=
		{
			"LANEvoque2016_Wheel_1_1",
			"LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2"
		};
	};
	class ProxyLANEvoque2016_Wheel_5: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_5.p3d";
		inventorySlot[]=
		{
			"LANEvoque2016_Wheel_1_1",
			"LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2"
		};
	};
	class ProxyLANEvoque2016_Wheel_6: ProxyVehiclePart
	{
		model="Projects\CZRangeRoverEvoque2016\vehicles\LandroverEvoque2016\Proxy\LANEvoque2016_Wheel_6.p3d";
		inventorySlot[]=
		{
			"LANEvoque2016_Wheel_1_1",
			"LANEvoque2016_Wheel_1_2",
			"LANEvoque2016_Wheel_2_1",
			"LANEvoque2016_Wheel_2_2"
		};
	};
};
